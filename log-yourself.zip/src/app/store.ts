// import { INCREMENT, FETCH_ALL_LOGS_ERROR, FETCH_ALL_LOGS_SUCCESS } from './actions';

// export interface IAppState {
//   counter?: number;
//   test?: any;
//   // type?: any;
// }

// export const INITIAL_STATE: IAppState = {
//   counter: 0,

// };

// export function rootReducer(state: IAppState, action): IAppState {
//   switch (action.type) {
//     case INCREMENT: return { counter: state.counter + 5 };
//     case FETCH_ALL_LOGS_ERROR: return { counter: state.counter + 15 };
//   }
//   return state;
// }
