# LogYourself

This project was created as a learning tool for getting familiar with MEAN stack. ( MongoDB, Express.js, Angular 2 and NodeJs).

## Progressive Web App
I have also tried to implement PWA's functionality, meaning app can work offline and can be added to a smartphone's desktop without a need to install from app store.
In future I will add possiblity for database to be saved locally and therefore reach full offline-capabilites.

## Demos
 [Demo](https://secret-forest-91881.herokuapp.com/). (App is hosted on a free tier on Heroku, so give it a few seconds to load the database)
 [StackBlitz Demo](https://stackblitz.com/github/jacksylvane/log-yourself).
